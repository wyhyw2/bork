# 火花管家 · 手环端快应用（BandSpark QuickApp）

小米手环 9 Pro 上的「火花面板」，与手机端 BandSpark App 通过 `@system.interconnect` 联动。

## 核心设计：必须连接手机 App + 激活才能用

**单独安装手环端 .rpk 无法使用**。三个状态门禁：

| 状态 | 触发条件 | 界面 |
|------|----------|------|
| `未连接` | 没装手机 App / 手机 App 没运行 / 签名不一致 | 显示“未连接手机 App” |
| `未激活` | 已连接，但手机端用户未激活卡密 | 显示“未激活会员” |
| `已激活` | 已连接 + 手机端已激活 | 显示火花天数 + 话术 + 续火/换话术按钮 |

- 手环端每次 `syncStatus` 请求，手机端只在**已激活**时回 `spark-status`（含天数+话术），否则回 `spark-not-activated`；
- “续火/换话术”按钮只在 `ready` 状态渲染，未连接/未激活时根本不出现。

## 通信协议（interconnect）

### 手环 → 手机（spark-command）

```json
{ "type": "spark-command", "action": "syncStatus",   "payload": {},            "t": 1234567890 }
{ "type": "spark-command", "action": "send",         "payload": { "phrase": "..." }, "t": 1234567890 }
{ "type": "spark-command", "action": "changePhrase", "payload": {},            "t": 1234567890 }
```

### 手机 → 手环

```json
{ "type": "spark-status",        "payload": { "sparkDays": 12, "phrase": "..." } }
{ "type": "spark-not-activated", "payload": {} }
{ "type": "spark-result",        "payload": { "action": "send", "ok": true, "sparkDays": 13 } }
{ "type": "spark-result",        "payload": { "action": "changePhrase", "ok": true, "phrase": "..." } }
```

## ⚠️ 致命前提：签名必须一致

**手环 .rpk 的签名证书，必须和手机 App 的签名证书一模一样**，否则手环发送的数据会被手机系统拦截，报“签名不匹配”。

- 用一个 keystore 同时签 `.rpk` 和 `.apk`；
- 打包 .rpk 时（aiot release）用同一个 keystore 签名；
- 手机 BandSpark APK 也用同一个 keystore 签名。

## 手机端（BandSpark）需要做的事

用**小米官方 interconnect 接收 SDK** 监听，处理 `spark-command`：

1. `syncStatus` → 若 `VipManager.isVip()` 为真，回 `spark-status`（天数=Prefs.sparkDays，话术=MessagePool.current）；否则回 `spark-not-activated`；
2. `send` → 调 `DouyinEngine.runTargets` 发送，成功后回 `spark-result(ok=true, sparkDays=+1)`；
3. `changePhrase` → `MessagePool.next()`，回 `spark-result(ok=true, phrase=新话术)`。

## 构建

1. 装 Node.js + `aiot-toolkit`（`npm install`）；
2. 放入图标 `src/common/logo.png`；
3. `npm run release` → 产物在 `dist/`，生成 `.rpk`；
4. 用**与手机 App 相同的 keystore** 签名；
5. 用表盘自定义工具“蓝牙一键安装”或 AstroBox 装到手环。

## 项目结构

```
BandSparkQuickApp/
├── package.json
└── src/
    ├── manifest.json          # 声明 system.interconnect 功能
    ├── app.ux                 # 生命周期：启停 interconnect 桥
    ├── pages/index/index.ux   # 页面：火花天数 + 续火/换话术 + 激活门禁
    ├── utils/sparkBridge.js   # interconnect 通信桥
    └── common/logo.png        # 图标（需自行放入）
```
