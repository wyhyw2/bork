// Vela 快应用支持 require() 方式加载系统模块（参考 BandQQ，避开 import 在部分构建下的问题）
const interconnect = require('@system.interconnect');

/**
 * 火花管家 · 手环端通信桥（interconnect）
 *
 * 手环 → 手机：sendCommand(action, payload) 发送 spark-command
 * 手机 → 手环：onmessage 接收 spark-status / spark-not-activated / spark-result
 *
 * 通信前提：
 *   1. 手机端 BandSpark App 必须已运行（用小米官方 SDK 监听 interconnect）；
 *   2. .rpk 的签名证书必须与手机 App 签名证书完全一致，否则系统拦截“签名不匹配”；
 *   3. 手机 App 只在用户已激活会员时下发 spark-status，否则下发 spark-not-activated。
 */

let connection = null;
let statusListener = null;
let connected = false;

function notify(msg) {
  if (statusListener && msg) {
    try {
      statusListener(msg);
    } catch (e) {}
  }
}

function start() {
  if (connection) return;
  try {
    connection = interconnect.instance();
  } catch (e) {
    console.error('[SparkBridge] instance failed:', e && e.message);
    return;
  }

  connection.onmessage = (event) => {
    let msg = event && event.data !== undefined ? event.data : event;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { msg = null; }
    }
    if (msg && typeof msg === 'object') notify(msg);
  };

  connection.onopen = () => {
    connected = true;
    notify({ type: 'spark-connected' });
  };

  connection.onerror = (event) => {
    console.error('[SparkBridge] error:', event && event.code);
  };

  connection.onclose = () => {
    connected = false;
    notify({ type: 'spark-disconnected' });
  };

  console.log('[SparkBridge] started');
}

function sendCommand(action, payload) {
  if (!connection || !connected) {
    notify({ type: 'spark-disconnected' });
    return false;
  }
  connection.send({
    data: { type: 'spark-command', action: action, payload: payload || {}, t: Date.now() },
    success: () => {},
    fail: (data, code) => {
      console.error('[SparkBridge] send failed:', action, code);
      notify({ type: 'spark-disconnected' });
    }
  });
  return true;
}

function setStatusListener(cb) {
  statusListener = cb;
}

function stop() {
  if (connection) {
    connection.onmessage = null;
    connection.onopen = null;
    connection.onerror = null;
    connection.onclose = null;
  }
  connection = null;
  connected = false;
}

export default { start, stop, sendCommand, setStatusListener };
